
public class Road implements Comparable<Road> {

	private Town source;
	private Town destination;
	private int weight;
	private String name;
	
	/**
	 * Constructor
	 * @param source
	 * @param destination
	 * @param degrees
	 * @param name
	 */
	public Road(Town source, Town destination, int degrees, String name) {
		this.source = source;
		this.destination = destination;
		this.weight = degrees;
		this.name = name;
	}
	
	/**
	 * Constructor with weight preset at 1
	 * @param source
	 * @param destination
	 * @param name
	 */
	public Road (Town source, Town destination, String name){
		this.source = source;
		this.destination = destination;
		this.weight = 1;
		this.name = name;
	}
	
	/**
	 * Returns true only if the edge contains the given town
	 * @param town - a vertex of the graph
	 * @return true only if the edge is connected to the given vertex
	 */
	public boolean contains(Town town) {
		if(source.equals(town) || destination.equals(town)) {
			return true;
		}
		
		return false;
	}
	
	/**
	 * 
	 */
	public String toString() {
		
		return source.getName() + " via " + name + " to " + destination.getName() + " " + weight
		        + " mi";
	}
	
	/**
	 * Returns the road name
	 * @return the name of the road
	 */
	public String getName() {
		return this.name;
	}
	
	/**
	 * Returns the second town on the road
	 * @return a town on the road
	 */
	public Town getDestination() {
		return this.destination;
	}
	
	/**
	 * Returns the first town on the road
	 * @return a town on the road
	 */
	public Town getSource() {
		return this.source;
	}
	
	/**
	 * @return 0 if the road names are the same, a positive or negative number if the road names are not the same
	 */
	@Override
	public int compareTo(Road o) {
		return this.name.compareTo(o.getName());
	}
	
	/**
	 * Returns the distance of the road
	 * @return the distance of the road
	 */
	public int getWeight() {
		return this.weight;
	}
	
	/**
	 * Returns true if each of the ends of the road r is the same as the ends of this road. Remember that a road that goes from point A to point B is the same as a road that goes from point B to point A.
	 * @param r - road object to compare it to
	 */
	public boolean equals(Object r) {
		Road c = (Road) r;
		if(c.getSource().equals(new Town(source)) && c.getDestination().equals(new Town(destination)) || c.getSource().equals(new Town(destination)) && c.getDestination().equals(new Town(source))) {		
			return true;	
		}
		return false;
	}
	
	
	
	
	
	

}
