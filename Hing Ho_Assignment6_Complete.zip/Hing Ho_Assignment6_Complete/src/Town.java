
public class Town implements Comparable<Town> {

	private String name;
	
	/**
	 * Constructor. Requires town's name
	 * @param name
	 */
	public Town (String name) {		
		this.name = name;	
	}
		
	/**
	 * Copy constructor.
	 * @param templateTown - an instance of Town
	 */
	public Town (Town templateTown) {
		this.name = templateTown.getName();
	}
	
	/**
	 * Returns the town's name
	 * @return town's name
	 */
	public String getName() {
		return this.name;
	}
	
	/**
	 * Compare to method
	 * @param o
	 * @return 0 if names are equal, a positive or negative number if the names are not equal
	 */
	public int compareTo(Town o) {
		if(o.getName().equals(name)) {
			return 0;
		}
		else {
			return name.compareTo(o.getName());
		}			
	}
	
	/**
	 * To string method
	 * @return the town name
	 */
	public String toString() {
		return this.name;
	}
	
	/**
	 * @return the hashcode for the name of the town
	 */
	public int hashCode() {
		return this.name.hashCode();
	}
	
	/**
	 * @return true if the town names are equal, false if not
	 */
	public boolean equals(Object obj) {
		if (obj == null) {
	          return false;
	        }
	        if (obj == this) {
	          return true;
	        }
		Town t = (Town)obj;
		return this.name.equals(t.getName());
		
	}
	
	
	
	
}
